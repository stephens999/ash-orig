#' ashr
#'
#' @name ashr
#' @docType package
NULL
